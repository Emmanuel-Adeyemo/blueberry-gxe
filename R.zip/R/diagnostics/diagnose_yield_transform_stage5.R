# 10/22
#
# Comprehensive check of whether log(y + yield_log_offset) is actually
# warranted for yield at the STAGE 5 (single-trial) level, vs. relying on
# eyeballing two trials (BW 2023/2025) as was done when the transform was
# first adopted (see prepare_yield_for_qc.R).
#
# Deliberately NOT wired into _targets.R: this is a one-off diagnostic to
# be run and read by a person, not a pipeline step anything downstream
# depends on. Run it from the project root (same place you'd run
# targets::tar_make()) with:
#
#   source('R/R/...')   # already done by _targets.R-style sourcing, or:
#   targets::tar_source()                  # loads R/R/*.R if you have a
#                                           # live targets store already
#   source('R/diagnostics/diagnose_yield_transform_stage5.R')
#   out <- run_stage5_transform_diagnostics()
#
# This fits ONE trial at a time, genotype + block as FIXED effects via
# plain lm() -- not the asreml/sommer random-genotype model Stage 5 itself
# uses for H2/Re/CV. That's intentional: fixed-effect residuals are the
# right tool for a residual-vs-fitted / QQ / mean-variance check (that's
# literally what "residual-vs-fitted diagnostics on BW 2023/2025" already
# meant), and lm() is fast enough to run across every trial, not just two,
# without needing asreml licensed/available in whatever session runs this.
#
# What this produces, across EVERY AL/NC/FL yield trial (not a hand-picked
# pair):
#   1. Residual-vs-fitted and scale-location plots, raw vs sqrt vs log, faceted by
#      Env -- the funnel/S-curve check, done systematically.
#   2. QQ plots of residuals, raw vs sqrt vs log, faceted by Env.
#   3. Breusch-Pagan test + Shapiro-Wilk test + skewness, raw vs sqrt vs log, one
#      row per Env -- a numeric readout of (1)/(2), not just "eyeball it".
#   4. The actual justification for log in the first place: does
#      across-trial error VARIANCE scale with the trial MEAN (Taylor's
#      power law)? Fit log(var) ~ log(mean) across all trials' raw-scale
#      residual variance; slope ~2 is the classic "needs log" signature,
#      slope ~0 means variance doesn't depend on the mean and log isn't
#      buying anything. Repeated WITH and WITHOUT BW 2023/EV 2023, since
#      those two trials' means are 15-45x lower than every other trial and
#      could be single-handedly driving (or distorting) that slope.
#   5. Per-trial Box-Cox profile (on y + offset, the same positive series
#      actually used in production) -- an independent, model-based way to
#      ask "what power transform does this trial's own data want", rather
#      than assuming log (lambda = 0) is right everywhere.
#
# Everything lands in one PDF (diagnostic plots) + one CSV (the per-Env
# numeric table) + a console summary verdict.

suppressMessages({
  library(dplyr)
  library(tidyr)
  library(ggplot2)
  library(purrr)
  library(tibble)
})

# ---------------------------------------------------------------------------
# 1. Build one raw (PRE-log), subplot-level yield table per Env.
#
# Deliberately reuses aggregate_yield_for_qc() for AL so this is the exact
# same subplot-level aggregation Stage 5 itself uses -- the only thing
# different here is we stop BEFORE the log() is applied (build_per_trial_
# qc_dta()/build_per_trial_qc_dta_nc_fl() only expose the already-logged
# version via $dta$TotalYield, so that can't be reused directly for this).
# NC/FL yield is already subplot-level by the time it reaches
# nc_yield_clean/fl_yield_clean (confirmed in compute_yield_log_offset()),
# so those just get filtered + renamed, no re-aggregation needed.
# ---------------------------------------------------------------------------

build_raw_yield_trial_list = function(al_yield_long_clean, nc_yield_clean, fl_yield_clean,
                                       fl_block_col = 'subplot', nc_block_col = 'subplot') {

  al_envts = al_yield_long_clean %>% distinct(season, location)
  nc_envts = nc_yield_clean %>% distinct(season, location)
  fl_envts = fl_yield_clean %>% distinct(season, location)

  al_list = al_envts %>%
    pmap(function(season, location) {
      yield_env = al_yield_long_clean[al_yield_long_clean$season == season & al_yield_long_clean$location == location, ]
      aggregate_yield_for_qc(yield_env) %>%
        transmute(genotype = as.character(Genotype), block = as.character(BlockNo), y = TotalYield)
    })
  names(al_list) = paste(al_envts$location, al_envts$season)

  nc_list = nc_envts %>%
    pmap(function(season, location) {
      nc_yield_clean[nc_yield_clean$season == season & nc_yield_clean$location == location, ] %>%
        transmute(genotype = as.character(genotype), block = as.character(.data[[nc_block_col]]), y = y)
    })
  names(nc_list) = paste(nc_envts$location, nc_envts$season)

  fl_list = fl_envts %>%
    pmap(function(season, location) {
      fl_yield_clean[fl_yield_clean$season == season & fl_yield_clean$location == location, ] %>%
        transmute(genotype = as.character(genotype), block = as.character(.data[[fl_block_col]]), y = y)
    })
  names(fl_list) = paste(fl_envts$location, fl_envts$season)

  trial_list = c(al_list, nc_list, fl_list)

  # drop anything degenerate (no variance / all NA / too few rows for a
  # genotype+block fixed-effect model to even be identified) rather than
  # letting lm() error out mid-loop
  trial_list[sapply(trial_list, function(d) {
    d = d %>% filter(!is.na(y))
    nrow(d) >= 10 && length(unique(d$genotype)) >= 3 && stats::sd(d$y, na.rm = TRUE) > 0
  })]
}


# ---------------------------------------------------------------------------
# 2. Fit genotype+block (fixed) on raw y, sqrt(y), and log(y+offset), per
#    Env, and pull out tidy residual/fitted frames for all three scales.
#
# sqrt(y) needs no offset -- it's defined at y = 0 directly (unlike log,
# which needs the offset specifically to handle the real zeros), which is
# itself one of the reasons it's worth checking as an alternative: it
# sidesteps the offset-sensitivity question entirely for the trials with
# true zero yields.
#
# Falls back to genotype-only (no block term) if block has < 2 usable
# levels -- some FL plantings and sparse trials won't support a block
# effect, and failing the whole diagnostic over that would defeat the
# point of checking EVERY trial rather than a hand-picked pair.
# ---------------------------------------------------------------------------

fit_all_scales = function(trial_dta, offset) {

  trial_dta = trial_dta %>% filter(!is.na(y))
  trial_dta$genotype = factor(trial_dta$genotype)
  trial_dta$block = factor(trial_dta$block)
  trial_dta$y_log = log(trial_dta$y + offset)
  trial_dta$y_sqrt = sqrt(trial_dta$y)

  has_block = nlevels(trial_dta$block) >= 2 &&
    all(table(trial_dta$block) > 0) &&
    nlevels(trial_dta$block) < nrow(trial_dta)

  resp_col = c(raw = 'y', sqrt = 'y_sqrt', log = 'y_log')

  fit_one = function(scale_label) {
    resp = resp_col[[scale_label]]
    form = if (has_block) {
      reformulate(c('genotype', 'block'), response = resp)
    } else {
      reformulate('genotype', response = resp)
    }
    m = tryCatch(lm(form, data = trial_dta), error = function(e) NULL)
    if (is.null(m) || length(residuals(m)) < 5) return(NULL)
    tibble(
      scale = scale_label,
      fitted = fitted(m),
      resid = residuals(m),
      obs_y = trial_dta[[resp]]
    )
  }

  bind_rows(lapply(names(resp_col), fit_one))
}


# ---------------------------------------------------------------------------
# 3. Numeric diagnostics per Env x scale: Breusch-Pagan (heteroscedasticity),
#    Shapiro-Wilk (normality), skewness. All implemented directly (no
#    lmtest/moments dependency) so this runs with just base R + tidyverse.
# ---------------------------------------------------------------------------

breusch_pagan = function(resid, fitted) {
  if (length(unique(fitted)) < 2) return(c(stat = NA_real_, p = NA_real_))
  aux = lm(resid^2 ~ fitted)
  n = length(resid)
  r2 = summary(aux)$r.squared
  stat = n * r2
  p = pchisq(stat, df = 1, lower.tail = FALSE)
  c(stat = stat, p = p)
}

skewness = function(x) {
  x = x[!is.na(x)]
  n = length(x)
  m = mean(x); s = stats::sd(x)
  if (s == 0 || n < 3) return(NA_real_)
  (sum((x - m)^3) / n) / s^3
}

shapiro_p = function(x) {
  x = x[!is.na(x)]
  if (length(x) < 5 || length(x) > 5000 || stats::sd(x) == 0) return(NA_real_)
  tryCatch(shapiro.test(x)$p.value, error = function(e) NA_real_)
}

summarize_env_scale = function(resid_df, env) {
  resid_df %>%
    group_by(scale) %>%
    summarise(
      n = n(),
      resid_var = var(resid),
      bp_stat = breusch_pagan(resid, fitted)['stat'],
      bp_p = breusch_pagan(resid, fitted)['p'],
      shapiro_p = shapiro_p(resid),
      skew = skewness(resid),
      .groups = 'drop'
    ) %>%
    mutate(Env = env, .before = 1)
}


# ---------------------------------------------------------------------------
# 4. Per-trial Box-Cox profile on (y + offset) -- independent check of
#    what power transform each trial's own data wants, vs. assuming
#    lambda = 0 (log) is correct everywhere. Wrapped in tryCatch: MASS's
#    boxcox() needs a positive response and a non-degenerate design, which
#    a couple of sparse trials may not satisfy.
# ---------------------------------------------------------------------------

boxcox_lambda_for_trial = function(trial_dta, offset) {
  trial_dta = trial_dta %>% filter(!is.na(y))
  trial_dta$genotype = factor(trial_dta$genotype)
  trial_dta$block = factor(trial_dta$block)
  trial_dta$y_pos = trial_dta$y + offset

  has_block = nlevels(trial_dta$block) >= 2 && nlevels(trial_dta$block) < nrow(trial_dta)
  form = if (has_block) y_pos ~ genotype + block else y_pos ~ genotype

  tryCatch({
    bc = MASS::boxcox(form, data = trial_dta, plotit = FALSE,
                       lambda = seq(-2, 2, by = 0.05))
    bc$x[which.max(bc$y)]
  }, error = function(e) NA_real_)
}


# ---------------------------------------------------------------------------
# 5. Taylor's power law across trials: log(residual variance) ~ log(trial
#    mean), fit with and without the BW 2023/EV 2023 outlier trials. This
#    is the actual quantitative version of "yield has a mean-variance
#    relationship" -- slope near 2 says variance scales with mean^2 (the
#    textbook log-stabilizes-this case); slope near 0 says it doesn't.
# ---------------------------------------------------------------------------

fit_taylors_law = function(env_summary_raw, exclude_envs = character(0)) {
  dta = env_summary_raw %>% filter(resid_var > 0, mean_y > 0)
  dta_incl = dta
  dta_excl = dta %>% filter(!Env %in% exclude_envs)

  fit_slope = function(d) {
    if (nrow(d) < 3) return(c(slope = NA_real_, intercept = NA_real_, r2 = NA_real_))
    m = lm(log(resid_var) ~ log(mean_y), data = d)
    c(slope = unname(coef(m)[2]), intercept = unname(coef(m)[1]), r2 = summary(m)$r.squared)
  }

  list(
    with_outliers    = fit_slope(dta_incl),
    without_outliers = fit_slope(dta_excl),
    data             = dta
  )
}


# ---------------------------------------------------------------------------
# 6. Top-level driver: run everything, build plots, save PDF + CSV, print
#    a console verdict.
# ---------------------------------------------------------------------------

run_stage5_transform_diagnostics = function(al_yield_long_clean, nc_yield_clean, fl_yield_clean,
                                              yield_log_offset,
                                              outlier_envs = c('BW 2023', 'EV 2023'),
                                              out_pdf = 'stage5_yield_transform_diagnostics.pdf',
                                              out_csv = 'stage5_yield_transform_summary.csv') {

  trial_list = build_raw_yield_trial_list(al_yield_long_clean, nc_yield_clean, fl_yield_clean)

  message('Fitting raw + log models for ', length(trial_list), ' trials: ',
          paste(names(trial_list), collapse = ', '))

  resid_list = imap(trial_list, ~ fit_all_scales(.x, yield_log_offset) %>% mutate(Env = .y, .before = 1))
  resid_all = bind_rows(resid_list) %>%
    mutate(scale = factor(scale, levels = c('raw', 'sqrt', 'log')))

  env_scale_summary = map2_dfr(resid_list, names(resid_list), ~ summarize_env_scale(.x, .y)) %>%
    distinct()

  # trial means/sds on the RAW scale, for the mean-variance step
  raw_means = imap_dfr(trial_list, ~ tibble(Env = .y, mean_y = mean(.x$y, na.rm = TRUE),
                                             sd_y = stats::sd(.x$y, na.rm = TRUE)))

  env_summary = env_scale_summary %>%
    pivot_wider(id_cols = Env, names_from = scale,
                values_from = c(n, resid_var, bp_stat, bp_p, shapiro_p, skew),
                names_glue = '{scale}_{.value}') %>%
    left_join(raw_means, by = 'Env')

  env_summary_raw = env_summary %>% transmute(Env, mean_y, resid_var = raw_resid_var)

  taylor = fit_taylors_law(env_summary_raw, exclude_envs = outlier_envs)

  message('Fitting per-trial Box-Cox profiles...')
  boxcox_lambdas = imap_dfr(trial_list, ~ tibble(Env = .y, boxcox_lambda = boxcox_lambda_for_trial(.x, yield_log_offset)))

  env_summary = env_summary %>% left_join(boxcox_lambdas, by = 'Env')

  # ---- plots ----

  p_resid_fitted = resid_all %>%
    ggplot(aes(fitted, resid)) +
    geom_point(alpha = 0.5, size = 0.8) +
    geom_hline(yintercept = 0, linetype = 2, color = 'red') +
    geom_smooth(se = FALSE, linewidth = 0.5, color = 'blue') +
    facet_grid(Env ~ scale, scales = 'free') +
    labs(title = 'Residual vs fitted, raw vs sqrt vs log', x = 'Fitted', y = 'Residual') +
    theme_bw(base_size = 8)

  p_scale_location = resid_all %>%
    ggplot(aes(fitted, sqrt(abs(resid)))) +
    geom_point(alpha = 0.5, size = 0.8) +
    geom_smooth(se = FALSE, linewidth = 0.5, color = 'blue') +
    facet_grid(Env ~ scale, scales = 'free') +
    labs(title = 'Scale-location (funnel check), raw vs sqrt vs log', x = 'Fitted', y = 'sqrt(|Residual|)') +
    theme_bw(base_size = 8)

  p_qq = resid_all %>%
    group_by(Env, scale) %>%
    mutate(theoretical = qqnorm(resid, plot.it = FALSE)$x) %>%
    ungroup() %>%
    ggplot(aes(theoretical, resid)) +
    geom_point(alpha = 0.5, size = 0.8) +
    geom_abline(slope = 1, intercept = 0, linetype = 2, color = 'red') +
    facet_grid(Env ~ scale, scales = 'free') +
    labs(title = 'QQ plot of residuals, raw vs sqrt vs log', x = 'Theoretical quantile', y = 'Residual') +
    theme_bw(base_size = 8)

  p_taylor = taylor$data %>%
    mutate(is_outlier_env = Env %in% outlier_envs) %>%
    ggplot(aes(log(mean_y), log(resid_var))) +
    geom_point(aes(color = is_outlier_env), size = 2.5) +
    geom_text(aes(label = Env), vjust = -0.8, size = 2.8) +
    geom_smooth(data = ~ filter(.x, !is_outlier_env), method = 'lm', se = FALSE,
                linewidth = 0.5, color = 'darkgreen') +
    geom_smooth(method = 'lm', se = FALSE, linewidth = 0.5, linetype = 2, color = 'black') +
    scale_color_manual(values = c('FALSE' = 'grey40', 'TRUE' = 'red')) +
    labs(
      title = "Taylor's power law: log(residual variance) vs log(trial mean), raw scale",
      subtitle = sprintf(
        'slope (all trials) = %.2f, R2 = %.2f  |  slope (excl. %s) = %.2f, R2 = %.2f',
        taylor$with_outliers['slope'], taylor$with_outliers['r2'],
        paste(outlier_envs, collapse = '/'),
        taylor$without_outliers['slope'], taylor$without_outliers['r2']
      ),
      x = 'log(trial mean yield)', y = 'log(residual variance)', color = 'Outlier trial'
    ) +
    theme_bw(base_size = 9)

  p_boxcox = env_summary %>%
    ggplot(aes(x = reorder(Env, boxcox_lambda), y = boxcox_lambda)) +
    geom_col(fill = 'steelblue') +
    geom_hline(yintercept = 0, linetype = 2, color = 'red') +
    geom_hline(yintercept = 1, linetype = 3, color = 'grey40') +
    coord_flip() +
    labs(
      title = 'Per-trial Box-Cox optimal lambda (0 = log, 1 = no transform)',
      x = NULL, y = 'lambda'
    ) +
    theme_bw(base_size = 9)

  pdf(out_pdf, width = 9, height = 11)
  print(p_resid_fitted)
  print(p_scale_location)
  print(p_qq)
  print(p_taylor)
  print(p_boxcox)
  dev.off()

  readr::write_csv(env_summary, out_csv)

  # ---- console verdict ----
  cat('\n==== Stage 5 yield transform diagnostics ====\n')
  cat(sprintf('Trials checked: %d\n', nrow(env_summary)))
  cat(sprintf(
    "\nTaylor's law slope -- ALL trials: %.2f (R2=%.2f)   excl. %s: %.2f (R2=%.2f)\n",
    taylor$with_outliers['slope'], taylor$with_outliers['r2'],
    paste(outlier_envs, collapse = '/'),
    taylor$without_outliers['slope'], taylor$without_outliers['r2']
  ))
  cat('  (slope ~2 => variance scales with mean^2, classic log-justifying pattern;\n')
  cat('   slope ~0 => variance roughly constant across trials, log not obviously needed;\n')
  cat('   compare the two numbers above to see how much BW 2023/EV 2023 alone drive this.)\n')

  cat('\nPer-trial verdict (raw-scale problems that log scale resolves):\n')
  verdict = env_summary %>%
    transmute(
      Env,
      raw_heteroscedastic = raw_bp_p < 0.05,
      sqrt_heteroscedastic = sqrt_bp_p < 0.05,
      log_heteroscedastic = log_bp_p < 0.05,
      raw_nonnormal = raw_shapiro_p < 0.05,
      sqrt_nonnormal = sqrt_shapiro_p < 0.05,
      log_nonnormal = log_shapiro_p < 0.05,
      boxcox_lambda = round(boxcox_lambda, 2)
    )
  print(as.data.frame(verdict), row.names = FALSE)

  cat(sprintf('\nFull table written to %s\nPlots written to %s\n', out_csv, out_pdf))

  list(
    resid_all = resid_all,
    env_summary = env_summary,
    taylor = taylor,
    plots = list(resid_fitted = p_resid_fitted, scale_location = p_scale_location,
                 qq = p_qq, taylor = p_taylor, boxcox = p_boxcox)
  )
}