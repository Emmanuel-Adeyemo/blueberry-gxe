# 10/22
#
# Quick, standalone check: does the frost-trio clustering (BW 2023,
# EV 2023, EV 2026) recover under sqrt(y) instead of log(y+offset) for
# yield at Stage 7 (the joint FA model), the way it did before any
# transform was applied?
#
# Deliberately NOT wired into _targets.R and NOT yet editing
# stage07_fa_model.R itself -- this mirrors stage07_fa_model.R's own
# al_prep_yield/nc_prep_yield/prep_yield/g_inv/a_inv/fit_fa3_asr/
# env_levels/rg_fa3_asr/hc_fa3_asr targets exactly, just swapping the
# yield transform, so you can compare this output directly against the
# log-scale FA3 (no FL) dendrogram/corr you already have before deciding
# whether to carry the Stage 5 sqrt switch into Stage 7 for real.
#
# FL stays excluded here, matching the already-settled Stage 7 decision
# (weak connectivity -> unreliable correlations feeding the shared-L1
# OP/RMSD calculation) -- this check is only about log vs. sqrt, not
# about re-opening the FL question.
#
# Run from the project root with the targets store already built (so
# al_yield_long_clean, nc_yield_clean, g_mat are available), e.g.:
#
#   targets::tar_load(c(al_yield_long_clean, nc_yield_clean, g_mat))
#   source('R/diagnostics/verify_stage7_sqrt_frost_trio.R')
#   out <- run_stage7_sqrt_frost_check(al_yield_long_clean, nc_yield_clean, g_mat)
#
# `out$rg$corr` is the additive genetic correlation matrix (same object
# you've been pasting back for the log-scale models); `out$hc_plot` is
# the dendrogram. print_frost_trio_submatrix(out$rg$corr) pulls just the
# BW 2023 / EV 2023 / EV 2026 x all-Envs rows so the comparison against
# the earlier log-scale result doesn't require hunting through the full
# 10x10 table.

suppressMessages({
  library(dplyr)
})

build_prep_yield_sqrt = function(al_yield_long_clean, nc_yield_clean, exclude_genotype = 'TH-2937') {

  al_prep = prepare_fa_dta(
    aggregate_yield_for_qc(al_yield_long_clean) %>%
      dplyr::mutate(TotalYield = sqrt(TotalYield)),
    'TotalYield'
  )

  nc_prep = prepare_nf_fa_dta(
    nc_yield_clean %>% dplyr::mutate(y = sqrt(y)),
    'y', block_col = 'subplot'
  )

  rbind(al_prep, nc_prep) %>%
    filter(Genotype != exclude_genotype)
}

run_stage7_sqrt_frost_check = function(al_yield_long_clean, nc_yield_clean, g_mat,
                                        out_pdf = 'stage7_sqrt_frost_check.pdf') {

  prep_yield_sqrt = build_prep_yield_sqrt(al_yield_long_clean, nc_yield_clean)

  a_inv_sqrt = build_A_inverse(g_mat, unique(prep_yield_sqrt$Genotype))

  message('Fitting FA3 (sqrt yield, AL+NC, no FL)...')
  fit_fa3_sqrt = fit_fa3_asreml(prep_yield_sqrt, a_inv_sqrt)

  env_levels_sqrt = levels(factor(prep_yield_sqrt$Env))

  rg_fa3_sqrt = extract_rg_matrix_asreml(summary(fit_fa3_sqrt)$varcomp, env_levels_sqrt, 3)

  hc_fa3_sqrt = plot_hc(rg_fa3_sqrt$corr, 'AsReml FA3 (sqrt yield, no FL)')

  pdf(out_pdf, width = 8, height = 6)
  print(hc_fa3_sqrt)
  dev.off()

  cat('\n==== FA3 (sqrt yield, AL+NC, no FL) -- additive correlation matrix ====\n')
  print(round(rg_fa3_sqrt$corr, 2))

  cat('\n==== Frost-trio submatrix (BW 2023 / EV 2023 / EV 2026 vs. everything) ====\n')
  print_frost_trio_submatrix(rg_fa3_sqrt$corr)

  cat(sprintf('\nDendrogram written to %s -- compare directly against the log-scale FA3 (no FL) dendrogram.\n', out_pdf))

  list(
    fit = fit_fa3_sqrt,
    rg = rg_fa3_sqrt,
    hc_plot = hc_fa3_sqrt,
    prep_yield = prep_yield_sqrt,
    env_levels = env_levels_sqrt,
    mods_comp = data.frame(
      Model    = 'FA3_sqrt',
      LogL     = fit_fa3_sqrt$loglik,
      N_params = fit_fa3_sqrt$nwv,
      AIC      = summary(fit_fa3_sqrt)$aic,
      BIC      = summary(fit_fa3_sqrt)$bic
    )
  )
}

print_frost_trio_submatrix = function(corr, frost_envs = c('BW 2023', 'EV 2023', 'EV 2026')) {
  frost_envs = intersect(frost_envs, rownames(corr))
  if (length(frost_envs) == 0) {
    message('None of the expected frost-trio Env labels (', paste(frost_envs, collapse = ', '),
            ') were found in this correlation matrix -- check env naming/season labels.')
    return(invisible(NULL))
  }
  print(round(corr[frost_envs, , drop = FALSE], 2))
}

# Convenience: flag any |correlation| >= this threshold as a possible
# boundary/degenerate estimate, the same red flag that was found in
# FA2_ke1/FA3_ke1's log-scale correlations (exact +/-1.00 pairs). Run
# this on BOTH the sqrt result and, if you still have it, the log-scale
# FA3 result, to see whether sqrt is also prone to this or not.
flag_boundary_correlations = function(corr, threshold = 0.97) {
  corr_off_diag = corr
  diag(corr_off_diag) = NA
  flagged = which(abs(corr_off_diag) >= threshold, arr.ind = TRUE)
  if (nrow(flagged) == 0) {
    cat(sprintf('No off-diagonal |correlation| >= %.2f -- no boundary/degenerate pairs flagged.\n', threshold))
    return(invisible(NULL))
  }
  data.frame(
    Env1 = rownames(corr)[flagged[, 1]],
    Env2 = colnames(corr)[flagged[, 2]],
    corr = corr[flagged]
  ) %>% dplyr::distinct(corr, .keep_all = TRUE)
}