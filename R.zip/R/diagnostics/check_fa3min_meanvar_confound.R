# 10/23
#
# Checks a specific claim made in discussion, not yet verified: that
# FA3_min's raw-scale "significant" non-additive variance (LRT vs plain
# FA3) was tracking a mean-variance SCALING ARTIFACT rather than real
# environment-specific non-additive genetic signal, and that sqrt removes
# this -- which is why FA3_min goes from significant (raw) to ns (sqrt).
#
# IMPORTANT CORRECTION to how that claim was first framed in discussion:
# every FA model here is fit on y_scaled = (y - mean_env) / sd_env (see
# prep_and_scale_dta() in R/R/prepare_fa_dta.R), computed and divided out
# BEFORE the model ever sees the data. That forces Var(y_scaled | Env) to
# ~1 for every environment by construction -- so a BETWEEN-environment
# story ("environments with bigger raw yield have bigger raw variance,
# and that leaks into psi") cannot be the mechanism: the z-scoring step
# mechanically removes exactly that signal before fitting. Checking
# psi vs raw per-Env MEAN yield (included below as `mean_y`, for
# completeness/contrast) should therefore show little to no correlation,
# and finding none there is expected, not a failure of the hypothesis.
#
# The channel z-scoring does NOT touch is WITHIN-trial heteroscedasticity
# -- variance increasing with a genotype's own yield level inside one
# trial (exactly what diagnose_yield_transform_stage5.R's Breusch-Pagan
# test on y ~ genotype + block residuals measures, per trial, per scale).
# Z-scoring an environment uniformly rescales the whole trial; it does
# nothing to equalize variance ACROSS genotypes within that trial. If
# raw yield's within-trial heteroscedasticity is real (Stage 5 already
# found it is, for most trials), dsum(~units|Env)'s single residual
# variance per Env is misspecified for it (it assumes one common
# residual variance for every genotype in that Env) -- and the excess,
# genotype-linked variance from high-yielding genotypes has nowhere to
# go except a genotype-indexed term that CAN absorb it: ide(Genotype),
# i.e. FA3_min's non-additive term. That predicts: psi (FA3_min's fitted
# non-additive variance) should correlate with each trial's own raw-scale
# Breusch-Pagan statistic; and once sqrt stabilizes that within-trial
# heteroscedasticity (which Stage 5 found it mostly does), the sqrt-scale
# psi should correlate much more weakly (or not at all) with the sqrt-
# scale BP statistic.
#
# This is the actual check for that mechanism -- not the between-Env
# mean-yield story floated first, which the z-scoring step rules out.
#
# Run from the project root with the targets store already built:
#
#   targets::tar_source()   # loads R/R/*.R
#   targets::tar_load(c(al_yield_long_clean, nc_yield_clean, fl_yield_clean,
#                        g_mat, prep_yield, fit_fa3_min_asr))
#   source('R/diagnostics/check_fa3min_meanvar_confound.R')
#   out <- run_fa3min_confound_check(al_yield_long_clean, nc_yield_clean,
#                                     fl_yield_clean, g_mat, prep_yield,
#                                     fit_fa3_min_asr)
#
# `fl_yield_clean` is only needed to build the per-trial BP diagnostics
# (same reuse as diagnose_yield_transform_stage5.R); FL stays excluded
# from the FA3_min fits themselves, matching the settled Stage 7 Env
# definition.

suppressMessages({
  library(dplyr)
  library(purrr)
  library(tibble)
})

# Reuse the Stage 5 diagnostic's own BP-test machinery instead of
# reimplementing it a second time (and risking the two drifting apart) --
# only sources if these aren't already loaded in this session.
if (!exists('build_raw_yield_trial_list') || !exists('fit_all_scales') || !exists('breusch_pagan')) {
  source('R/diagnostics/diagnose_yield_transform_stage5.R')
}


# ---------------------------------------------------------------------------
# Per-trial Breusch-Pagan statistic, raw and sqrt scale, AL+NC only (no FL
# -- matches the Env set FA3_min is actually fit on). offset is unused by
# either scale we care about here; fit_all_scales() still computes a log
# column internally, harmlessly, since it's not read downstream.
# ---------------------------------------------------------------------------
build_trial_bp_stats = function(al_yield_long_clean, nc_yield_clean, fl_yield_clean) {
  trial_list = build_raw_yield_trial_list(al_yield_long_clean, nc_yield_clean, fl_yield_clean)
  trial_list = trial_list[grepl('^(BW|EV|NC) ', names(trial_list))]  # drop FL trials

  resid_list = imap(trial_list, ~ fit_all_scales(.x, offset = 1) %>% mutate(Env = .y, .before = 1))

  imap_dfr(resid_list, function(df, env) {
    df %>%
      group_by(scale) %>%
      summarise(bp_stat = breusch_pagan(resid, fitted)['stat'], .groups = 'drop') %>%
      mutate(Env = env, .before = 1)
  }) %>%
    filter(scale %in% c('raw', 'sqrt')) %>%
    tidyr::pivot_wider(id_cols = Env, names_from = scale, values_from = bp_stat,
                        names_glue = '{scale}_bp_stat')
}


# ---------------------------------------------------------------------------
# Build raw-scale (untransformed) yield FA data, mirroring al_prep_yield/
# nc_prep_yield/prep_yield in stage07a_fa_yield_model.R exactly except for
# the sqrt() call -- same aggregation, same TH-2937 exclusion, same AL+NC
# (no FL) Env set.
# ---------------------------------------------------------------------------
build_prep_yield_raw = function(al_yield_long_clean, nc_yield_clean, exclude_genotype = 'TH-2937') {
  al_prep = prepare_fa_dta(aggregate_yield_for_qc(al_yield_long_clean), 'TotalYield')
  nc_prep = prepare_nf_fa_dta(nc_yield_clean, 'y', block_col = 'subplot')
  rbind(al_prep, nc_prep) %>% filter(Genotype != exclude_genotype)
}


# ---------------------------------------------------------------------------
# Pull FA3_min's fitted per-Env non-additive variance (psi) out of an
# asreml varcomp table, matched to Env labels by name rather than assumed
# row order. Falls back to row order (with a loud warning + the raw row
# names printed) if name-matching doesn't find a clean 1:1 mapping -- this
# keeps the fallback visibly checkable instead of silently trusted, since
# asreml's exact row-name format for diag(Env):ide(Genotype) terms can
# vary and wasn't verified against a live fit here (no R interpreter in
# this sandbox).
# ---------------------------------------------------------------------------
match_env_varcomp = function(varcomp_sub, env_levels) {
  rn = rownames(varcomp_sub)
  rn_nospace = gsub('[[:space:]]', '', rn)

  find_one = function(e) {
    e_nospace = gsub('[[:space:]]', '', e)
    hit = which(grepl(e, rn, fixed = TRUE) | grepl(e_nospace, rn_nospace, fixed = TRUE))
    if (length(hit) == 1) hit else NA_integer_
  }
  found = sapply(env_levels, find_one)

  if (!anyNA(found) && length(unique(found)) == length(env_levels)) {
    tibble(Env = env_levels, psi = varcomp_sub[found, 1], varcomp_rowname = rn[found])
  } else {
    warning(
      'match_env_varcomp(): could not uniquely match every Env label to a ',
      'varcomp row by name -- falling back to ROW ORDER (assumes varcomp_sub ',
      'rows are in the same order as env_levels). VERIFY this against the ',
      'raw row names printed below before trusting the correlation numbers.'
    )
    stopifnot(nrow(varcomp_sub) == length(env_levels))
    tibble(Env = env_levels, psi = varcomp_sub[, 1], varcomp_rowname = rn)
  }
}


# ---------------------------------------------------------------------------
# Driver: fit FA3_min on raw yield (refit -- raw scale isn't in
# production, so there's no stored target for it), reuse the already-fit
# production FA3_min for sqrt (fit_fa3_min_asr, passed in -- avoids a
# second expensive asreml fit), extract psi for both, join against each
# Env's raw mean yield (expected weak/no correlation, per the correction
# above) and each Env's own-scale Breusch-Pagan statistic (expected
# correlation on raw, much weaker on sqrt, if the within-trial-
# heteroscedasticity mechanism is right), and report.
# ---------------------------------------------------------------------------
run_fa3min_confound_check = function(al_yield_long_clean, nc_yield_clean, fl_yield_clean,
                                      g_mat, prep_yield_sqrt, fit_fa3_min_sqrt,
                                      out_pdf = 'fa3min_confound_check.pdf') {

  message('Building raw-scale yield FA data (AL + NC, no FL, no transform)...')
  prep_yield_raw = build_prep_yield_raw(al_yield_long_clean, nc_yield_clean)
  env_levels_raw = levels(factor(prep_yield_raw$Env))

  message('Building raw-scale A-inverse and fitting FA3_min on RAW yield (refit; not in production)...')
  a_inv_raw = build_A_inverse(g_mat, unique(prep_yield_raw$Genotype))
  fit_raw = fit_fa3_min_asreml(prep_yield_raw, a_inv_raw)

  message('Computing per-trial Breusch-Pagan statistics (raw vs sqrt), AL + NC only...')
  bp_stats = build_trial_bp_stats(al_yield_long_clean, nc_yield_clean, fl_yield_clean)

  # per-Env raw mean yield -- included for contrast; expected to show
  # little/no correlation with psi given the z-scoring argument above.
  env_mean_raw = prep_yield_raw %>%
    group_by(Env) %>% summarise(mean_y = mean(y, na.rm = TRUE), .groups = 'drop')
  env_mean_sqrt = prep_yield_sqrt %>%
    group_by(Env) %>% summarise(mean_y = mean(y, na.rm = TRUE), .groups = 'drop')

  psi_raw = match_env_varcomp(split_varcomp_asreml(summary(fit_raw)$varcomp)$nonadditive, env_levels_raw)
  psi_sqrt = match_env_varcomp(split_varcomp_asreml(summary(fit_fa3_min_sqrt)$varcomp)$nonadditive,
                                levels(factor(prep_yield_sqrt$Env)))

  raw_check = psi_raw %>%
    inner_join(env_mean_raw, by = 'Env') %>%
    inner_join(bp_stats %>% dplyr::select(Env, bp_stat = raw_bp_stat), by = 'Env')

  sqrt_check = psi_sqrt %>%
    inner_join(env_mean_sqrt, by = 'Env') %>%
    inner_join(bp_stats %>% dplyr::select(Env, bp_stat = sqrt_bp_stat), by = 'Env')

  cor_raw_mean = suppressWarnings(cor(raw_check$mean_y, raw_check$psi))
  cor_raw_bp   = suppressWarnings(cor(raw_check$bp_stat, raw_check$psi))
  cor_sqrt_mean = suppressWarnings(cor(sqrt_check$mean_y, sqrt_check$psi))
  cor_sqrt_bp   = suppressWarnings(cor(sqrt_check$bp_stat, sqrt_check$psi))

  cat('\n==== RAW-scale FA3_min psi, per-Env mean yield, per-Env BP stat (VERIFY mapping by eye) ====\n')
  print(as.data.frame(raw_check))
  cat('\n==== SQRT-scale FA3_min psi, per-Env mean yield, per-Env BP stat (VERIFY mapping by eye) ====\n')
  print(as.data.frame(sqrt_check))

  cat(sprintf('\nRAW scale:  cor(psi, Env mean yield) = %.3f   |   cor(psi, Env Breusch-Pagan stat) = %.3f\n',
              cor_raw_mean, cor_raw_bp))
  cat(sprintf('SQRT scale: cor(psi, Env mean yield) = %.3f   |   cor(psi, Env Breusch-Pagan stat) = %.3f\n',
              cor_sqrt_mean, cor_sqrt_bp))

  cat(
    '\nExpected pattern if the within-trial-heteroscedasticity explanation is\n',
    'correct: cor(psi, mean_y) weak on BOTH scales (z-scoring already removes\n',
    'that channel before fitting -- a strong hit here would actually be\n',
    'unexpected and worth a second look); cor(psi, bp_stat) clearly positive\n',
    'on RAW and much weaker on SQRT -- that specific contrast is the real\n',
    'test of the claim, not the mean_y columns.\n', sep = ''
  )

  pdf(out_pdf, width = 9, height = 8)
  op = par(mfrow = c(2, 2))
  plot(raw_check$mean_y, raw_check$psi, pch = 19, xlab = 'Env mean yield (raw)', ylab = 'psi (FA3_min)',
       main = sprintf('RAW: psi vs mean (r=%.2f)', cor_raw_mean))
  text(raw_check$mean_y, raw_check$psi, labels = raw_check$Env, pos = 3, cex = 0.6)

  plot(raw_check$bp_stat, raw_check$psi, pch = 19, xlab = 'Env Breusch-Pagan stat (raw)', ylab = 'psi (FA3_min)',
       main = sprintf('RAW: psi vs BP stat (r=%.2f)', cor_raw_bp))
  text(raw_check$bp_stat, raw_check$psi, labels = raw_check$Env, pos = 3, cex = 0.6)
  abline(lm(psi ~ bp_stat, data = raw_check), col = 'red', lty = 2)

  plot(sqrt_check$mean_y, sqrt_check$psi, pch = 19, xlab = 'Env mean yield (sqrt)', ylab = 'psi (FA3_min)',
       main = sprintf('SQRT: psi vs mean (r=%.2f)', cor_sqrt_mean))
  text(sqrt_check$mean_y, sqrt_check$psi, labels = sqrt_check$Env, pos = 3, cex = 0.6)

  plot(sqrt_check$bp_stat, sqrt_check$psi, pch = 19, xlab = 'Env Breusch-Pagan stat (sqrt)', ylab = 'psi (FA3_min)',
       main = sprintf('SQRT: psi vs BP stat (r=%.2f)', cor_sqrt_bp))
  text(sqrt_check$bp_stat, sqrt_check$psi, labels = sqrt_check$Env, pos = 3, cex = 0.6)
  abline(lm(psi ~ bp_stat, data = sqrt_check), col = 'red', lty = 2)
  par(op)
  dev.off()

  cat(sprintf('\nPlot written to %s\n', out_pdf))

  list(
    fit_raw = fit_raw, fit_sqrt = fit_fa3_min_sqrt,
    raw_check = raw_check, sqrt_check = sqrt_check,
    cor_raw_mean = cor_raw_mean, cor_raw_bp = cor_raw_bp,
    cor_sqrt_mean = cor_sqrt_mean, cor_sqrt_bp = cor_sqrt_bp
  )
}