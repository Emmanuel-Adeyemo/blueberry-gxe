# 10/23
#
# Direct check of the trial network's GENOTYPE x ENVIRONMENT connectivity
# -- how many genotypes are shared between each pair of the 10
# environments, and how many environments the typical genotype appears
# in -- as distinct from within-trial replication (reps/subplots), which
# is a different axis of statistical power entirely.
#
# Why this matters: the additive FA term (vm(Genotype, Ainv)) borrows
# strength across genotypes via the pedigree/relationship matrix, so it
# tolerates sparse/unbalanced testing reasonably well -- even a genotype
# tested in only one Env still gets information from how its relatives
# perform elsewhere. The non-additive term (ide(Genotype), no
# relationship matrix) has no such borrowing: it can ONLY use genotypes
# directly repeated across environments to estimate anything
# environment-specific about non-additive effects. So its identifiability
# depends on genotype overlap BETWEEN environment pairs, not on how many
# reps/subplots exist WITHIN a single trial (that axis of power looks
# fine per the 10/23 discussion and isn't in question here). This script
# makes that overlap visible directly instead of asserting it, so the
# weakest-connected Env pairs below can be checked against whichever
# pairs showed up as boundary/degenerate (near +/-1.00) in FA3_ke1's
# non-additive correlation matrix (boundary_fa3_ke1_nonadd_asr /
# flag_boundary_correlations()).
#
# Run from the project root with the targets store built:
#
#   targets::tar_source()
#   targets::tar_load(prep_yield)
#   source('R/diagnostics/check_env_connectivity.R')
#   out <- run_connectivity_check(prep_yield)
#
# prep_yield is production's sqrt-scale AL+NC yield FA data (TH-2937
# excluded), but genotype/Env incidence doesn't depend on the trait
# transform at all -- any prepare_fa_dta()/prepare_nf_fa_dta()-shaped
# table (Genotype, Env, Block, y) works identically here, including a
# different trait's FA data if you want to check connectivity for that
# trait's own Env set instead.

suppressMessages({
  library(dplyr)
  library(tidyr)
  library(tibble)
})

# ---------------------------------------------------------------------------
# genotype x Env incidence: number of plot-level observations genotype g
# has in environment e (0 if untested there).
# ---------------------------------------------------------------------------
build_genotype_env_incidence = function(fa_dta) {
  counts = fa_dta %>%
    dplyr::count(Genotype, Env, name = 'n_obs')

  wide = counts %>%
    tidyr::pivot_wider(names_from = Env, values_from = n_obs, values_fill = 0)

  geno = wide$Genotype
  mat = as.matrix(wide[, -1, drop = FALSE])
  rownames(mat) = geno
  mat
}


# ---------------------------------------------------------------------------
# Env x Env connectivity: off-diagonal = number of genotypes tested in
# BOTH environments (what a correlated non-additive factor between that
# pair actually has to be estimated from); diagonal = total genotypes
# tested in that Env at all (relevant to diag(Env):ide(Genotype)'s
# per-Env psi).
# ---------------------------------------------------------------------------
compute_env_connectivity = function(incidence) {
  presence = (incidence > 0) * 1
  t(presence) %*% presence
}


# ---------------------------------------------------------------------------
# Per genotype: how many environments it appears in at all (degree), and
# mean within-Env reps where it does appear -- the two axes of power this
# check is about keeping separate, shown side by side.
# ---------------------------------------------------------------------------
compute_genotype_degree = function(incidence) {
  tibble::tibble(
    Genotype = rownames(incidence),
    n_envs = rowSums(incidence > 0),
    mean_reps_per_env = sapply(seq_len(nrow(incidence)), function(i) {
      row = incidence[i, ]
      row = row[row > 0]
      if (length(row) == 0) NA_real_ else mean(row)
    })
  ) %>% dplyr::arrange(n_envs)
}


run_connectivity_check = function(fa_dta, out_pdf = 'env_connectivity_check.pdf') {

  incidence = build_genotype_env_incidence(fa_dta)
  conn = compute_env_connectivity(incidence)
  degree = compute_genotype_degree(incidence)

  n_env = ncol(incidence)
  env_levels = colnames(incidence)

  cat('\n==== Per-Env total genotype count (connectivity matrix diagonal) ====\n')
  print(data.frame(Env = env_levels, n_genotypes = diag(conn)))

  cat('\n==== Env x Env genotype overlap (off-diagonal = shared genotypes) ====\n')
  print(conn)

  off_diag = conn
  diag(off_diag) = NA
  pairs = which(upper.tri(off_diag), arr.ind = TRUE)
  overlap_tab = tibble::tibble(
    Env1 = env_levels[pairs[, 1]],
    Env2 = env_levels[pairs[, 2]],
    shared_genotypes = conn[pairs]
  ) %>% dplyr::arrange(shared_genotypes)

  cat('\n==== Weakest-connected Env pairs (fewest shared genotypes) ====\n')
  print(as.data.frame(utils::head(overlap_tab, 15)))

  cat(sprintf(
    '\nOverlap summary across all %d Env pairs: min=%d, median=%.0f, mean=%.1f, max=%d\n',
    nrow(overlap_tab), min(overlap_tab$shared_genotypes), stats::median(overlap_tab$shared_genotypes),
    mean(overlap_tab$shared_genotypes), max(overlap_tab$shared_genotypes)
  ))

  cat('\n==== Per-genotype: how many of the 10 Envs it was tested in ====\n')
  deg_summary = degree %>%
    dplyr::count(n_envs, name = 'n_genotypes') %>%
    dplyr::arrange(n_envs)
  print(as.data.frame(deg_summary))

  cat(sprintf(
    '\n%d of %d genotypes (%.0f%%) were tested in only 1 Env (no cross-Env comparison possible for these at all).\n',
    sum(degree$n_envs == 1), nrow(degree), 100 * mean(degree$n_envs == 1)
  ))
  cat(sprintf(
    'Median Envs per genotype: %.0f out of %d total.\n',
    stats::median(degree$n_envs), n_env
  ))
  cat(sprintf(
    'Median within-Env reps per genotype (where tested): %.1f -- the OTHER axis (within-trial replication), shown for contrast; this is not what limits the non-additive-by-Env term.\n',
    stats::median(degree$mean_reps_per_env, na.rm = TRUE)
  ))

  cat(
    '\nRead the weakest-connected pairs above against boundary_fa3_ke1_nonadd_asr /\n',
    'flag_boundary_correlations(): an Env pair with very few shared genotypes\n',
    'here is exactly where a correlated non-additive factor has the least real\n',
    'information to work with. If the pairs pinned near +/-1.00 there are also\n',
    'near the bottom of the overlap table above, that directly confirms thin\n',
    'cross-Env connectivity -- not the yield transform, not within-trial\n',
    'replication -- is the binding constraint on the non-additive term.\n',
    sep = ''
  )

  pdf(out_pdf, width = 9, height = 7)
  image(1:n_env, 1:n_env, conn, axes = FALSE, xlab = '', ylab = '',
        main = 'Env x Env genotype overlap (shared genotype count)',
        col = hcl.colors(20, 'Blues', rev = TRUE))
  axis(1, at = 1:n_env, labels = env_levels, las = 2, cex.axis = 0.8)
  axis(2, at = 1:n_env, labels = env_levels, las = 2, cex.axis = 0.8)
  for (i in 1:n_env) for (j in 1:n_env) {
    text(i, j, conn[i, j], cex = 0.7)
  }

  hist(degree$n_envs, breaks = seq(0.5, n_env + 0.5, by = 1), xlab = 'Number of Envs tested in',
       main = 'Genotype distribution across Envs (connectivity degree)', col = 'steelblue')
  dev.off()

  cat(sprintf('\nPlots written to %s\n', out_pdf))

  list(incidence = incidence, connectivity = conn, degree = degree, overlap_tab = overlap_tab)
}